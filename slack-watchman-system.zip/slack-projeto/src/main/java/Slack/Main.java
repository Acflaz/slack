package Slack;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.*;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {
        Conexao conexao = new Conexao();
        JdbcTemplate con = conexao.getConexaoDoBanco();
        try {

            List<Ranking> rankings = con.query(
                    "SELECT U.nome, R.qtdPontuacao\n"
                    + "FROM ranking R\n"
                    + "JOIN usuario U ON R.fkUsuario = U.idUsuario\n"
                    + "ORDER BY R.qtdPontuacao desc",
                    new BeanPropertyRowMapper<>(Ranking.class));
            int contador = 0;
            
            for (Ranking ranking : rankings) {
                String mensagem = "Nome: " + ranking.getNome() + ", Pontuação: " + ranking.getQtdPontuacao();
                exibirAlert(mensagem, contador);
                contador++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void exibirAlert(String mensagem, Integer posicao) throws IOException, InterruptedException {
        System.out.println(mensagem);
        JSONObject json = new JSONObject();
        if (posicao == 0){
            json.put("text", "Olá Supervisor, irei te aualizar sobre os primeiros colocados");
            Slack.sendMessage(json);
        }
        json.put("text", mensagem);

        Slack.sendMessage(json);
    }
}

//package Slack;
//
//import java.io.IOException;
//import java.util.Timer;
//import java.util.TimerTask;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import org.json.*;
//
//public class Main {
//
//    public static void main(String[] args) {
//        Timer timer = new Timer();
//        timer.schedule(new TimerTask() {
//            @Override
//
//            public void run() {
//                JSONObject json = new JSONObject();
//                json.put("text", "Oi");
//                try {
//                    Slack.sendMessage(json);
//                } catch (IOException ex) {
//                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//                } catch (InterruptedException ex) {
//                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//        }, 0, 5000);
//    }
//}
