package Slack;

public class Ranking {
    
    private Long id;
    private Integer qtdPontuacao;
    private String nome;
    private Integer fkUsuario;
    private Integer fkEmpresa;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getQtdPontuacao() {
        return qtdPontuacao;
    }

    public void setQtdPontuacao(Integer qtdPontuacao) {
        this.qtdPontuacao = qtdPontuacao;
    }

    public Integer getFkUsuario() {
        return fkUsuario;
    }

    public void setFkUsuario(Integer fkUsuario) {
        this.fkUsuario = fkUsuario;
    }

    public Integer getFkEmpresa() {
        return fkEmpresa;
    }

    public void setFkEmpresa(Integer fkEmpresa) {
        this.fkEmpresa = fkEmpresa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    

    @Override
    public String toString() {
        return "Ranking{" + "id=" + id + ", qtdPontuacao=" + qtdPontuacao + " Nome: " + nome;
    }
    
    
    
}
