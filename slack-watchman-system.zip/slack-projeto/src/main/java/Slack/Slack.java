package Slack;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.*;

public class Slack {

  private static final HttpClient client = HttpClient.newHttpClient();
  private static final String URL = "https://hooks.slack.com/services/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";

  public static void sendMessage(JSONObject content) throws IOException, InterruptedException {
    HttpRequest request = HttpRequest.newBuilder(
        URI.create(URL))
        .header("Content-Type", "application/json")
        .POST(HttpRequest.BodyPublishers.ofString(content.toString()))
        .build();

    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

    System.out.println(String.format("Status: %s", response.statusCode()));
    System.out.println(String.format("Response: %s", response.body()));
  }
}